#ifndef __UART_H
#define __UART_H
#include "csa37fx60.h"

void User_UART0_Init(void);
#endif
