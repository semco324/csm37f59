#ifndef __WDT_H
#define __WDT_H

#include "csa37fx60.h"

void User_WDT_Init(void);

void User_WDT_DISABLE(void);
#endif
