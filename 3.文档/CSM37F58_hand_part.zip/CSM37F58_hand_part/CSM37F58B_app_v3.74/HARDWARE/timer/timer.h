#ifndef __TIMER_H
#define __TIMER_H

#include "csa37fx60.h"
void timer0_init(void);
//void timer1_init(void);

#endif
