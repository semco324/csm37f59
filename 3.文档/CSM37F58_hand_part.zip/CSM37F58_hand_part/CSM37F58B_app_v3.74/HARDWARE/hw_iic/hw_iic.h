#ifndef __HW_IIC__H
#define __HW_IIC__H

#include "csa37fx60.h" 
void IIC_Init(void);
void IIC_Resume(void);
#endif
