
#ifndef _BIA_H_
#define _BIA_H_

//#ifndef _bia_h_
//#define _CS_BIAS_V1_3_1_h_
/*******************************
* @struct body_info_t
* @brief The body information.
*********************************/
typedef struct
{
  double bfp;        			   //!<Body Fat Percentage % 5~45
  double slm;      					 //!<Soft Lean Mass kg  7~141.5
  double bwp;      					 //!<Body Water Percentage % 20~85
  double bmc;     					 //!<Bone Mineral Content kg 1~4*   
  double pp;       					 //!<Protein Percentage % 5~32  
  double vfr;      					 //!<Viscera Fat Rank 1~59 
  double sbw;       				 //!<Standard Body Weight kg 16~105 
  double bmi;      					 //!<Body Mass Index kg/m^2 4~185.5
  double mc;       					 //!<Muscle Control kg -77~77
  double fc;       					 //!<Fat Control kg -65~45
  double wc;       					 //!<Weight Control kg -100~100
  short bmr;	   						 //!<Basal Metabolic Rate kcal 400~3500	
  unsigned char body_age; 	 //!<Metabolic Age years 15~80
  unsigned char sbc;      	 //!<Score of Body Composition �� 45~100
}bia_t;

/*****************************
* @struct bia_personal_info_t
* @brief The personal information.
********************************/
typedef struct
{
	short           height;
	short           weight;
	short           impedance;
	unsigned char   sex;
	unsigned char   age;
}bia_personal_info_t;

/******************************
* @fn char *bia_get_version(void)
* @brief Get the bia version.
* @param[out] None.
* @param[in]  None.
* @return the version
********************************/
const char *bia_get_version(void);

/***********************************************************
* @fn int bia_calc(bia_t *bia, bia_personal_info_t * ps_info)
* @brief It is used for bia parameters calc.
* @param[output] *bia The bia parameters.
* @param[input] *ps_info The  personal information.
* @return 0: ok, -1:failed
**************************************************************/
int bia_calc(bia_t *bia, bia_personal_info_t * ps_info);

 
#endif



