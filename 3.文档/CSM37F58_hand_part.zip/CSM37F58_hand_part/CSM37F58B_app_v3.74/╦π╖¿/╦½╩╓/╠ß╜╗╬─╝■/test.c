/*
 *-----------------------------------------------------------------------------
 * The confidential and proprietary information contained in this file may
 * only be used by a person authorised under and to the extent permitted
 * by a subsisting licensing agreement from  CHIPSEA.
 *
 *            (C) COPYRIGHT 2015 SHENZHEN CHIPSEA TECHNOLOGIES CO.,LTD.
 *                ALL RIGHTS RESERVED
 *
 * This entire notice must be reproduced on all copies of this file
 * and copies of this file may only be made by a person if such person is
 * permitted to do so under the terms of a subsisting license agreement
 * from CHIPSEA.
 *
 *      Release Information : CSA37FX60 Main function
 *-----------------------------------------------------------------------------
 */

//-------------------------------------------------------------------------------//
// Sample engineering documentation:
// 1. startup_CSA37FX60.s  For startup code;
// 2. absacc.h             Provides the ability to modify data in absolute addresses;
// 3. csa37fx60.h          Chip register mapping file;
//-------------------------------------------------------------------------------//

#include "csa37fx60.h"
#include "main_defs.h"
#include "absacc.h"

#include "csa37fx60_crc32.h"
#include "csa37fx60_gpio.h"
#include "csa37fx60_rcc.h"

#include "function.h"
#include  "bia.h"
const unsigned int CONFIG0 __at (0x00300000) = 0xE7FFFFFE; //WDT(disabled),Delay(500us),APROM,IAP(disabled)
const unsigned int CONFIG1 __at (0x00300004) = 0xFFFFE000; 


/**********************************
* @fn test_bia(unsigned int arg)
* @brief  printf body parameters
* @param[input] arg The arg parameters
* @return none
**********************************/
bia_t pbia_v131;
void test_bia(unsigned int arg)
{
    int i;
	  int ret;
//    bia_t pbia_v131;
    #if 0
		bia_personal_info_t input[16] = {
								{1000,381,5350,0,18},
                                {1500,381,5260,0,20},
                                {1300,381,5280,0,25},
                                {1000,381,5330,0,30},
                                {1650,380,5360,0,30},
                                {2200,382,5290,0,35},
                                {1800,380,5370,0,45},
                                {2000,381,5500,0,50},
                                {1000,380,5340,1,18},
                                {2000,380,5260,1,18},
                                {1800,380,5250,1,20},
                                {1400,381,5310,1,25},
                                {1650,380,5340,1,30},
                                {1500,380,5250,1,45},
                                {1000,382,5310,1,50},
                                {2200,381,5280,1,50}};
    #endif
		bia_personal_info_t input[1] = 	{1700,1000,6000,1,30};
		//printf("%s\n", bia_get_version());
											
    for(i=0; i<16; i++)
    {
        #if 1
				ret = bia_calc(&pbia_v131, &input[i]); 
        #endif 
        if(!ret)
        {
            #if 0
						printf("index %d\r\n", i);
						// 
						printf("B_BFB: %d ", (int)(pbia_v131.bfp * 10));
						// 
						printf("B_FM: %d ", (int)(pbia_v131.slm * 10));
						// 
						printf("B_SLM: %d ", (int)(pbia_v131.bwp * 10));
						// 
						printf("B_TFR: %d ", (int)(pbia_v131.bmc * 10));
						// 
						printf("B_TF: %d ", (int)(pbia_v131.pp * 10));
						// 
						printf("B_MSW: %d ", (int)(pbia_v131.vfr * 10));
						// 
						printf("B_VFR: %d ", (int)(pbia_v131.sbw * 10));
						// 
						printf("B_BW: %d ", (int)(pbia_v131.bmi * 10));
						// 
						printf("B_EXF: %d ", (int)(pbia_v131.mc * 10));
						// 
						printf("B_INF: %d ", (int)(pbia_v131.fc * 10));
						// 
						printf("B_LBM: %d ", (int)(pbia_v131.wc * 10));
					
						#endif
						// 
//						printf("B_PM: %d ", (int)(pbia_v131.bmr * 10));
//						// 
//						printf("B_EE: %d ", (int)(pbia_v131.body_age * 10));
//						//  
//						printf("B_OD: %d ", (int)(pbia_v131.sbc * 10));
			
        }
        else
        {
//            printf("calc error\r\n");
            break;
        }
		
    }    
    
}
/**********************************
* @fn void qca_user_main(void)
* @brief user main
* @param none
* @return none
**********************************/
int main (void) 
{   
    
    System_Init();//?????
    
    while(1)
    {
				test_bia(0);
			  while(1);
    }   
}
	

//System initial function	
void SystemInit(void)
{

}


/*Input parameters:

	{1000,381,5350,0,18},
    {1500,381,5260,0,20},
	{1300,381,5280,0,25},
	{1000,381,5330,0,30},
	{1650,380,5360,0,30},
	{2200,382,5290,0,35},
	{1800,380,5370,0,45},
	{2000,381,5500,0,50},
	{1000,380,5340,1,18},
	{2000,380,5260,1,18},
	{1800,380,5250,1,20},
	{1400,381,5310,1,25},
	{1650,380,5340,1,30},
	{1500,380,5250,1,45},
	{1000,382,5310,1,50},
	{2200,381,5280,1,50}};

Output parameters:

*/
