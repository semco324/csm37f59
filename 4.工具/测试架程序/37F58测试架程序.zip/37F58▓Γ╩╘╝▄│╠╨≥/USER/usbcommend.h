#ifndef __USBCOMMEND_H
#define __USBCOMMEND_H
#include "hw_config.h"
#include "usb_lib.h"
#include "usb_istr.h"
#include "delay.h"
#include "usb_io.h"
#include "myiic.h"

#define HEADER 0xA5
#define SET_COMMEND   0x5A //���ò�������
#define READ_COMMEND  0x5C //����ַ����
#define WRITE_COMMEND 0xC5 //д��ַ����

#define ERR_COMMEND 0xEE
#define ERR0        0xE0
#define ERR1        0xE1

extern u8  FromUSB_ReceiveFlg;
extern uint8_t  FromUSB_ReceiveBuf[64];
extern uint8_t  SendUSB_TransferBuf[64]; 

extern uint8_t ErrFlg;

#endif
