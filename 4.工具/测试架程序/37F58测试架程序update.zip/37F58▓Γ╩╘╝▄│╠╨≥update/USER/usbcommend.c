#include "usbcommend.h"


typedef enum{
	None_Commend = 0,     //û�и�����
	SetParm_Commend = 1,  //�����豸����
	ReadAddr_Commend = 2, //����ַ
	WriteAddr_Commend = 3,//д��ַ
}Commend;

Commend ComFlg = None_Commend;
bool SendFlg=FALSE;

//extern u16 SlaveAddr;   //�豸��ַ
//extern u8  SlaveAddrLen;//�豸��ַ�ֽ���
//extern u16 SubAddr;     //Ƭ�ڵ�ַ
//extern u8  SubAddrLen;  //Ƭ�ڵ�ַ�ֽ���
//extern uint8_t IICReadBuf[SIZE]; //��IIC����IICLen�����ݻ���
//extern uint8_t IICWriteBuf[SIZE];//��д��IICLen�����ݻ���
//extern uint16_t IICLen; //IIC��������



uint8_t cur_frame = 0,sum_frame = 0,ErrFlg = 0;
uint16_t Op_IICLen;
uint8_t ParseFlg=0,IICFlg=0;

void Commend_Parse(uint8_t* pdata) //����usb
{
	 uint8_t i,xor_temp = 0;
	 uint32_t temp = 0;
	
	  if(ParseFlg) return;
	
	  FromUSB_ReceiveFlg = TRUE; 
	  /**********��ͷ�ж�************/
		if(pdata[0] != HEADER)  //��ͷ�ж�
				{
					ErrFlg = 1; //��ͷ����
					ParseFlg=1;
					FromUSB_ReceiveFlg = FALSE;
					return;
				}
				
	  /**********У�����ж�************/
		xor_temp = 0;
    for(i = 0;i<(pdata[4]+4+1);i++)
				{
					xor_temp = xor_temp^pdata[i];
				}	
		if(xor_temp != pdata[(pdata[4]+4+1)])	
				{
					ErrFlg = 2; //У�����
			    ParseFlg=1;
					FromUSB_ReceiveFlg = FALSE;
					return;		
				}
		/////////////////////////////////
	
		cur_frame = pdata[1]; 
		sum_frame = pdata[2];
		
		if((cur_frame+1)==sum_frame) ParseFlg=1;
		
		switch(pdata[3])
		{
			case SET_COMMEND  :
			{ 
				SlaveAddr = 0;temp = 0;
			  SlaveAddrLen = pdata[5];           //�豸��ַ�ֽ��� 1
				
				for(i = (5+1);i<(5+1+SlaveAddrLen);i++)//�豸��ַ a0
				{ 
					temp = pdata[i];
					SlaveAddr = (SlaveAddr<<(8*(i-5-1)))|temp;
				}
								
				SubAddrLen = pdata[pdata[4]+4];    //Ƭ�ڵ�ַ�ֽ��� 2
				
				ComFlg = SetParm_Commend;
			}  break;
			
			case READ_COMMEND :
			{
				SubAddr = 0;temp = 0;
				for(i = (4+1);i<(4+1+SubAddrLen);i++) //��ʼ�����׵�ַ
					{
						temp = pdata[i];
					  SubAddr = (SubAddr<<(8*(i-5-1)))|temp;
					}
				temp = 0;
				for(i = (4+1+SubAddrLen);i<(4+1+pdata[4]);i++) //��ȡ����
					{
						temp = pdata[i];
					  IICLen = (IICLen<<(8*(i-5-1)))|temp;
					}
				if(IICLen>IIC_SIZE)IICLen=IIC_SIZE; //���SIZE
        Op_IICLen = IICLen;
				
			  ComFlg = ReadAddr_Commend;
			} break;
			case WRITE_COMMEND:
			{
				if(cur_frame == 0)  //����д��һ��
				{
					SubAddr = 0;temp = 0;
						for(i = (4+1);i<(4+1+SubAddrLen);i++) //��ʼд�׵�ַ
							{
								temp  =  pdata[i];
								SubAddr  =  (SubAddr<<(8*(i-5-1))) | temp;
							}
					IICLen = pdata[4]-SubAddrLen;
				}
				else           //�������ǵ�һ��
				{
					SubAddr = SubAddr + IICLen;//Ƭ�ڵ�ַ = �ϴε�ַ+�ϴ�д���ֽ���
					IICLen = pdata[4];
				}
				ComFlg = WriteAddr_Commend;
			} break;
			default :ComFlg = None_Commend;ParseFlg=1;break;
		}
		
}

//uint8_t counflg=0;
void Operate_IIC(Commend ComFlg,uint8_t* pdata) //�ش�usb
{   
	  uint8_t i,xor_temp = 0;
	  if(IICFlg) return;
	
	  
		if(ComFlg == None_Commend) {SendFlg = FALSE;IICFlg=1; return;}
		
    else if(ComFlg == SetParm_Commend)
		{
		   SendFlg = IIC_StateCheck(SlaveAddr);
			 IICFlg=1;		
		}
		
		else if(ComFlg == ReadAddr_Commend)
		{				
			  pdata[0]=0xA5;    //0
			  if(Op_IICLen == IICLen) {pdata[1]=0;pdata[2]=1;}	
				else {pdata[1]++;pdata[2]++;}   //1 2
			  pdata[3]=0x5C;   //3
        
        if(Op_IICLen<=(64-6))	
				      {							 
							 SendFlg = IIC_ReadDate(SlaveAddr,SubAddr,&IICReadBuf[0],Op_IICLen); 							 
							 pdata[4] = Op_IICLen;   //4
							 xor_temp=0;
							 for(i=0;i<Op_IICLen;i++)
   					        {
											pdata[i+5] = IICReadBuf[i];  //data
											xor_temp = xor_temp^pdata[i+5]; //data xor
										}						
							 for(i=0;i<(4+1);i++) xor_temp = xor_temp^pdata[i]; //xor 0~4
										
							 pdata[4+1+Op_IICLen] = xor_temp;   //last
							 IICFlg=1;Op_IICLen=0;		
							}
			 else
							{								
								SendFlg = IIC_ReadDate(SlaveAddr,SubAddr,&IICReadBuf[0],(64-6));
								Op_IICLen-=(64-6);
								pdata[4] = (64-6);   //4
								xor_temp=0;
								for(i=0;i<(64-6);i++)
											{
												pdata[i+5] = IICReadBuf[i];  //data
												xor_temp = xor_temp^pdata[i+5];//data xor
											}							
							  for(i=0;i<(5);i++)xor_temp = xor_temp^pdata[i]; //xor 0~4										 
								pdata[63]=xor_temp;              //last
							}	
		}
		
		else if(ComFlg == WriteAddr_Commend)
		{
			  pdata[0]=0xA5;    //0
			  if(cur_frame == 0) {pdata[1]=0;pdata[2]=1;}	
				else {pdata[1]++;pdata[2]++;}   //1 2
			  pdata[3]=0xC5;   //3
				
				if((cur_frame==0 && sum_frame ==1) || ((cur_frame+1)==sum_frame))
				{
				   IICFlg=1;			
				}
			  if(cur_frame == 0)
			  {
					  pdata[4]=IICLen;        //4
					  xor_temp=0;
						for(i=0;i<(IICLen);i++) //�����Ѿ���ȥ��SubAddrLen
									{
										IICWriteBuf[i]=FromUSB_ReceiveBuf[i+4+1+SubAddrLen];
										pdata[4+1+i]=IICWriteBuf[i];               //data
										xor_temp=xor_temp^pdata[4+1+i];				    //data xor						
									}
						for(i=0;i<(4+1);i++){xor_temp=xor_temp^pdata[i];} //xor 0~4
						
						pdata[5+IICLen]=xor_temp;
						
					  SendFlg = IIC_WriteDate(SlaveAddr,SubAddr,&IICWriteBuf[0],IICLen);
			  }			
				else 
				{
					  pdata[4]=IICLen;        //4
					  xor_temp=0;
						for(i=0;i<(IICLen);i++) //�����Ѿ���ȥ��SubAddrLen
									{
										IICWriteBuf[i]=FromUSB_ReceiveBuf[i+4+1];
										pdata[4+1+i]=IICWriteBuf[i];               //data
										xor_temp=xor_temp^pdata[4+1+i];				    //data xor						
									}
						for(i=0;i<(4+1);i++){xor_temp=xor_temp^pdata[i];} //xor 0~4
						
						pdata[5+IICLen]=xor_temp;
						
					  SendFlg = IIC_WriteDate(SlaveAddr,SubAddr,&IICWriteBuf[0],IICLen);
				}				
		}	
}


void Response_USB(uint8_t *pdata)
{
	

}







//			   {
//							SendUSB_TransferBuf[0] = pdata[0]; //��ͷ
//					    SendUSB_TransferBuf[1] = 0; //��ǰ����
//					    SendUSB_TransferBuf[1] = 1; //��
//				 }
