#include "usb_io.h"

void FromUSB_Receive(uint8_t *pReceiveBuf)
{
	 PMAToUserBufferCopy(pReceiveBuf, ENDP1_RXADDR, 64);
	 SetEPRxValid(ENDP1);
}

void SendData_ToUSB(uint8_t *pSendBuf)
{
	
	while(GetEPTxStatus(ENDP2)!=EP_TX_NAK) delay_ms(2);
		
	UserToPMABufferCopy(pSendBuf,ENDP2_TXADDR,64);
	SetEPTxCount(ENDP2,64);
	SetEPTxValid(ENDP2);
}
