#ifndef __USB_IO_H
#define __USB_IO_H

#include "hw_config.h"
#include "usb_lib.h"
#include "usb_istr.h"
#include "delay.h"

extern u8 FromUSB_ReceiveFlg;
extern uint8_t  FromUSB_ReceiveBuf[64]; //buf get data from usb 
extern uint8_t  SendBuf_ToUSB[64]; //

void FromUSB_Receive(uint8_t *pReceiveBuf);
void SendData_ToUSB(uint8_t *pSendBuf);

#endif

