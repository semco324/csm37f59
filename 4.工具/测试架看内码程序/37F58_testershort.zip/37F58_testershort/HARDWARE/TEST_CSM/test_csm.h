#ifndef __TEST_CSM_H
#define __TEST_CSM_H

#include "stm32f10x.h"
#include "myiic.h"
#include "key.h"
#include "lcd.h"
#include "adc.h"
#define DRDY1_GPIOX  GPIOB
#define DRDY1_CLOCK  RCC_APB2Periph_GPIOB
#define DRDY1_PIN    GPIO_Pin_12

#define RESET1_GPIOX  GPIOB
#define RESET1_CLOCK  RCC_APB2Periph_GPIOB
#define RESET1_PIN    GPIO_Pin_13

#define CE1_GPIOX  GPIOE
#define CE1_CLOCK  RCC_APB2Periph_GPIOE
#define CE1_PIN    GPIO_Pin_15

//Z12 Z14 Z13 Z23 Z24 Z34
#define Z12 0
#define Z14 1
#define Z13 2
#define Z23 3
#define Z24 4
#define Z34 5

#define READ_DRDY1() GPIO_ReadInputDataBit(DRDY1_GPIOX,DRDY1_PIN) //
void DRDY_Init(void);
void check_pre(void);
void cal_Measure(void);
void compare(void);
void check_sleep(void);
void sleep_m(void);
void test_res(void);
#endif
